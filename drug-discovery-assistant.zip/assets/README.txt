Place project images, logos, or screenshots in this folder.
The Streamlit app does not require an image to run.
