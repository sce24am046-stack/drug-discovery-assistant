# 🧪 MACHINE SPECTRA — Drug Discovery Assistant

An individual student machine-learning project that predicts the **aqueous solubility of chemical compounds** using molecular data.

## Project Overview

The Drug Discovery Assistant accepts a chemical compound as a **SMILES** string, calculates molecular descriptors with **RDKit**, and uses a machine-learning regression model to estimate aqueous solubility (`logS`).

### Workflow

```text
SMILES
  ↓
RDKit molecular structure
  ↓
Molecular descriptors
  ↓
Random Forest Regression
  ↓
Predicted logS
  ↓
Streamlit dashboard
```

## Features

- Enter custom SMILES
- Built-in example compounds
- Molecular-weight calculation
- LogP calculation
- TPSA calculation
- H-bond donor/acceptor counts
- Rotatable-bond count
- Ring count
- Heavy-atom count
- Fraction Csp3
- Solubility prediction
- CSV download

## Project Structure

```text
drug-discovery-assistant/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── .gitignore
├── data/
│   └── solubility.csv
├── models/
│   └── solubility_model.pkl
└── assets/
```

## Installation

Install Python 3.10 or newer.

Create and activate a virtual environment:

### Windows

```bash
python -m venv .venv
.venv\Scripts\activate
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Train the model

Run:

```bash
python train_model.py
```

This creates:

```text
models/solubility_model.pkl
```

## Run Streamlit

```bash
streamlit run app.py
```

The application will open in your browser.

## GitHub

Create a GitHub repository named:

```text
drug-discovery-assistant
```

Then:

```bash
git init
git add .
git commit -m "Initial Drug Discovery Assistant project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/drug-discovery-assistant.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

## Streamlit Community Cloud

1. Push the project to GitHub.
2. Open Streamlit Community Cloud.
3. Select **New app**.
4. Choose your GitHub repository.
5. Select `app.py`.
6. Deploy.

## Dataset Note

The included CSV is a small educational demonstration dataset. It is intentionally lightweight so the project can be understood and run easily.

For a serious research project, replace it with a properly curated public solubility dataset and report its source, preprocessing, train/test split, validation strategy, and model performance.

## Disclaimer

This project is for educational and research demonstration purposes. Predictions should not be interpreted as clinical, pharmaceutical, or regulatory conclusions.

## Author

**MACHINE SPECTRA**  
Individual Student Project  
**Drug Discovery Assistant**
