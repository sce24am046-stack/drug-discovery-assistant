import streamlit as st
import pandas as pd
import numpy as np
import joblib
from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen, Lipinski, rdMolDescriptors

st.set_page_config(
    page_title="MACHINE SPECTRA | Drug Discovery Assistant",
    page_icon="🧪",
    layout="wide",
)

st.markdown("""
<style>
.main {padding-top: 1rem;}
.hero {
    padding: 2rem;
    border-radius: 20px;
    background: linear-gradient(135deg, #111827, #312e81, #0f766e);
    color: white;
    margin-bottom: 1.5rem;
}
.hero h1 {font-size: 3rem; margin-bottom: .3rem;}
.card {
    padding: 1rem;
    border-radius: 14px;
    border: 1px solid rgba(128,128,128,.25);
    margin-bottom: 1rem;
}
.small {color: #9ca3af;}
</style>
""", unsafe_allow_html=True)

MODEL_PATH = "models/solubility_model.pkl"

@st.cache_resource
def load_model():
    try:
        return joblib.load(MODEL_PATH)
    except Exception:
        return None

def molecular_features(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, None

    features = {
        "MolWt": Descriptors.MolWt(mol),
        "LogP": Crippen.MolLogP(mol),
        "TPSA": rdMolDescriptors.CalcTPSA(mol),
        "HBD": Lipinski.NumHDonors(mol),
        "HBA": Lipinski.NumHAcceptors(mol),
        "RotatableBonds": Lipinski.NumRotatableBonds(mol),
        "RingCount": Lipinski.RingCount(mol),
        "HeavyAtomCount": Lipinski.HeavyAtomCount(mol),
        "FractionCSP3": rdMolDescriptors.CalcFractionCSP3(mol),
    }
    return mol, pd.DataFrame([features])

st.markdown("""
<div class="hero">
    <div class="small">MACHINE SPECTRA</div>
    <h1>🧪 Drug Discovery Assistant</h1>
    <p>Predicting the aqueous solubility of chemical compounds using molecular data.</p>
</div>
""", unsafe_allow_html=True)

st.sidebar.title("Navigation")
page = st.sidebar.radio("Choose a section", ["Predict Solubility", "About the Project"])

model = load_model()

if page == "Predict Solubility":
    st.subheader("🔬 Compound Analysis")
    st.write("Enter a valid chemical SMILES string to calculate molecular descriptors and predict solubility.")

    examples = {
        "Caffeine": "Cn1c(=O)c2c(ncn2C)n(C)c1=O",
        "Aspirin": "CC(=O)Oc1ccccc1C(=O)O",
        "Ibuprofen": "CC(C)Cc1ccc(cc1)[C@@H](C)C(=O)O",
        "Ethanol": "CCO",
        "Acetaminophen": "CC(=O)NC1=CC=C(C=C1)O",
    }

    selected = st.selectbox("Example compound", ["Custom"] + list(examples.keys()))
    default_smiles = "" if selected == "Custom" else examples[selected]

    smiles = st.text_input(
        "SMILES",
        value=default_smiles,
        placeholder="Example: CCO"
    )

    if st.button("🚀 Predict Solubility", type="primary"):
        if not smiles.strip():
            st.warning("Please enter a SMILES string.")
            st.stop()

        mol, feature_df = molecular_features(smiles.strip())

        if mol is None:
            st.error("Invalid SMILES. Please enter a valid chemical structure.")
            st.stop()

        st.success("Chemical structure successfully parsed.")

        st.subheader("📊 Molecular Properties")
        cols = st.columns(5)
        for i, (name, value) in enumerate(feature_df.iloc[0].items()):
            cols[i % 5].metric(name, f"{value:.3f}")

        if model is None:
            st.error(
                "The trained model was not found. Run `python train_model.py` first, "
                "then restart Streamlit."
            )
        else:
            prediction = float(model.predict(feature_df)[0])

            st.subheader("🤖 Solubility Prediction")
            c1, c2, c3 = st.columns(3)
            c1.metric("Predicted logS", f"{prediction:.3f}")
            c2.metric("Approx. molar solubility", f"{10**prediction:.3e} M")
            c3.metric("SMILES length", str(len(smiles.strip())))

            if prediction >= -1:
                interpretation = "High aqueous solubility"
            elif prediction >= -3:
                interpretation = "Moderate aqueous solubility"
            else:
                interpretation = "Low aqueous solubility"

            st.info(f"**Interpretation:** {interpretation}")

            result = feature_df.copy()
            result.insert(0, "SMILES", smiles.strip())
            result["Predicted_logS"] = prediction

            csv = result.to_csv(index=False).encode("utf-8")
            st.download_button(
                "⬇️ Download Prediction",
                csv,
                "solubility_prediction.csv",
                "text/csv",
            )

            st.caption(
                "Educational/research prototype. Predictions depend on the training data "
                "and should not be treated as clinical or regulatory conclusions."
            )

else:
    st.subheader("ℹ️ About MACHINE SPECTRA")
    st.markdown("""
    **Drug Discovery Assistant** is an individual student machine-learning project.

    ### Objective
    Predict the aqueous solubility of chemical compounds from molecular descriptors.

    ### Workflow
    1. User enters a compound as a SMILES string.
    2. RDKit converts the SMILES into a molecular structure.
    3. Molecular descriptors are calculated.
    4. A machine-learning regression model predicts `logS`.
    5. Streamlit presents the result interactively.

    ### Technology
    - Python
    - Streamlit
    - RDKit
    - Pandas / NumPy
    - Scikit-learn
    - Joblib

    ### Important
    This is an educational machine-learning demonstration. It is not a substitute
    for laboratory measurements, expert medicinal chemistry analysis, or regulatory testing.
    """)

st.sidebar.markdown("---")
st.sidebar.caption("MACHINE SPECTRA • Student Project")
