from pathlib import Path
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen, Lipinski, rdMolDescriptors

DATA_PATH = Path("data/solubility.csv")
MODEL_PATH = Path("models/solubility_model.pkl")

FEATURE_NAMES = [
    "MolWt", "LogP", "TPSA", "HBD", "HBA",
    "RotatableBonds", "RingCount", "HeavyAtomCount", "FractionCSP3"
]

def descriptors(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    return {
        "MolWt": Descriptors.MolWt(mol),
        "LogP": Crippen.MolLogP(mol),
        "TPSA": rdMolDescriptors.CalcTPSA(mol),
        "HBD": Lipinski.NumHDonors(mol),
        "HBA": Lipinski.NumHAcceptors(mol),
        "RotatableBonds": Lipinski.NumRotatableBonds(mol),
        "RingCount": Lipinski.RingCount(mol),
        "HeavyAtomCount": Lipinski.HeavyAtomCount(mol),
        "FractionCSP3": rdMolDescriptors.CalcFractionCSP3(mol),
    }

df = pd.read_csv(DATA_PATH)
rows = []

for _, row in df.iterrows():
    d = descriptors(row["smiles"])
    if d is not None:
        d["logS"] = row["logS"]
        rows.append(d)

clean = pd.DataFrame(rows)

X = clean[FEATURE_NAMES]
y = clean["logS"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestRegressor(
    n_estimators=300,
    random_state=42,
    max_depth=10,
    min_samples_leaf=1,
)
model.fit(X_train, y_train)

pred = model.predict(X_test)

print(f"MAE: {mean_absolute_error(y_test, pred):.3f}")
print(f"R2 : {r2_score(y_test, pred):.3f}")

MODEL_PATH.parent.mkdir(exist_ok=True)
joblib.dump(model, MODEL_PATH)

print(f"Saved model to: {MODEL_PATH}")
